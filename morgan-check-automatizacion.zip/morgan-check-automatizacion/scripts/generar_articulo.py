"""Ejecuta el equipo de agentes de Morgan Check y deja un artículo nuevo listo para revisión."""
import datetime
import json
import os
import re
import sys
from html.parser import HTMLParser
from pathlib import Path

import anthropic

RAIZ = Path(__file__).resolve().parent.parent
MODELO = os.environ.get("MODELO", "claude-sonnet-5-5")
MAX_INTENTOS = 3
client = anthropic.Anthropic()


def prompt(nombre):
    reglas = (RAIZ / "agentes" / "00-reglas.md").read_text(encoding="utf-8")
    return reglas + "\n\n" + (RAIZ / "agentes" / nombre).read_text(encoding="utf-8")


def llamar(sistema, usuario, buscar=False, max_tokens=6000):
    mensajes = [{"role": "user", "content": usuario}]
    kw = dict(model=MODELO, max_tokens=max_tokens, system=sistema)
    if buscar:
        kw["tools"] = [{"type": "web_search_20250305", "name": "web_search", "max_uses": 6}]
    for _ in range(6):
        r = client.messages.create(messages=mensajes, **kw)
        if r.stop_reason == "pause_turn":
            mensajes.append({"role": "assistant", "content": r.content})
            continue
        return "".join(b.text for b in r.content if b.type == "text")
    raise RuntimeError("La búsqueda no terminó a tiempo.")


def bloque(texto, lenguaje):
    m = re.search(r"```%s\s*(.*?)```" % lenguaje, texto, re.S)
    if not m:
        raise ValueError("Falta el bloque ```%s en la respuesta." % lenguaje)
    return m.group(1).strip()


def estado(texto):
    e = re.search(r"ESTADO:\s*(aprobado|devuelto)", texto, re.I)
    m = re.search(r"MOTIVOS:\s*(.*?)(?:```|\Z)", texto, re.S)
    if not e:
        raise ValueError("Falta ESTADO en la respuesta.")
    return e.group(1).lower(), (m.group(1).strip() if m else "")


class Validador(HTMLParser):
    TAGS = {"div", "h1", "h2", "p", "mark", "b", "i", "em", "strong", "ul", "li", "a", "span", "br"}

    def _revisar(self, tag, attrs):
        if tag not in self.TAGS:
            raise ValueError("Etiqueta no permitida: <%s>" % tag)
        for k, v in attrs:
            v = v or ""
            if k == "class" and re.fullmatch(r"[\w\- ]+", v):
                continue
            if k == "href" and v.startswith("https://"):
                continue
            if k == "style" and re.fullmatch(r"margin-top:\d{1,3}px;?", v):
                continue
            raise ValueError("Atributo no permitido: %s en <%s>" % (k, tag))

    def handle_starttag(self, tag, attrs):
        self._revisar(tag, attrs)

    def handle_startendtag(self, tag, attrs):
        self._revisar(tag, attrs)


def main():
    cal_path = RAIZ / "calendario.json"
    calendario = json.loads(cal_path.read_text(encoding="utf-8"))
    pendiente = next((t for t in calendario if not t["publicado"]), None)
    if not pendiente:
        print("No quedan temas pendientes en calendario.json.")
        Path("/tmp/pr_body.md").write_text("Sin temas pendientes.", encoding="utf-8")
        return
    tema = "Tema: %s\nCategoría: %s" % (pendiente["tema"], pendiente["categoria"])
    print("Tema:", pendiente["tema"])

    # 1-2. Investigador y Verificador
    ficha, devolucion = None, ""
    for i in range(MAX_INTENTOS):
        borrador = llamar(prompt("01-investigador.md"), tema + devolucion, buscar=True)
        veredicto = llamar(prompt("02-verificador.md"), borrador, buscar=True)
        est, motivos = estado(veredicto)
        print("Verificador:", est)
        if est == "aprobado":
            ficha = bloque(veredicto, "json")
            json.loads(ficha)
            break
        devolucion = "\n\nDevuelto por el Verificador:\n" + motivos
    if not ficha:
        sys.exit("El Verificador no aprobó la ficha tras %d intentos. Revisa el tema." % MAX_INTENTOS)

    # 3-4. Redactor y Editor
    html, cambios = None, ""
    for i in range(MAX_INTENTOS):
        texto = llamar(prompt("03-redactor.md"), "Ficha verificada:\n" + ficha + cambios)
        revision = llamar(prompt("04-editor.md"), "Ficha verificada:\n" + ficha + "\n\nTexto:\n" + texto)
        est, motivos = estado(revision)
        print("Editor:", est)
        if est == "aprobado":
            html = bloque(revision, "html")
            Validador().feed(html)
            break
        cambios = "\n\nCambios pedidos por el Editor:\n" + motivos
    if not html:
        sys.exit("El Editor no aprobó el texto tras %d intentos." % MAX_INTENTOS)

    # 5. Publicador
    meta = json.loads(bloque(llamar(prompt("05-publicador.md"), html), "json"))
    slug = re.sub(r"[^a-z0-9-]", "", meta["slug"].lower())[:50] or "articulo"
    hoy = datetime.date.today().isoformat()
    if (RAIZ / "articulos" / (slug + ".html")).exists():
        slug = "%s-%s" % (slug, hoy)
    (RAIZ / "articulos" / (slug + ".html")).write_text(html + "\n", encoding="utf-8")

    indice_path = RAIZ / "articulos.json"
    indice = json.loads(indice_path.read_text(encoding="utf-8"))
    indice.insert(0, {"slug": slug, "titulo": meta["titulo"], "categoria": meta["categoria"],
                      "resumen": meta["resumen"], "lectura": meta["lectura"], "fecha": hoy})
    indice_path.write_text(json.dumps(indice, ensure_ascii=False, indent=2), encoding="utf-8")

    pendiente["publicado"] = True
    cal_path.write_text(json.dumps(calendario, ensure_ascii=False, indent=2), encoding="utf-8")

    cuerpo = ("Artículo generado por los agentes: **%s**\n\n"
              "Antes de aprobar, revisa:\n- [ ] Las fuentes existen y dicen lo que se les atribuye.\n"
              "- [ ] No hay datos sin respaldo ni tono alarmista.\n- [ ] El texto se ve bien en el sitio.\n\n"
              "Ficha verificada:\n```json\n%s\n```\n" % (meta["titulo"], ficha))
    Path("/tmp/pr_body.md").write_text(cuerpo, encoding="utf-8")
    print("Listo:", slug)


if __name__ == "__main__":
    main()
